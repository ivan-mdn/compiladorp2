package leandrowilson.compiladorp2;

public enum TipoDescritor {
	VAL_STRING,
	VAL_BOOL,
	VAL_INT,
	VAR_STRING,
	VAR_BOOL,
	VAR_INT,
	VVAR_STRING,
	VVAR_BOOL,
	VVAR_INT;
}
